import React, { useState,useEffect } from 'react';
import MaterialTable from 'material-table';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFilter } from '@fortawesome/free-solid-svg-icons';
import './index.css';
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { Col, Row, Button, Form, FormGroup, Label, Input } from 'reactstrap';
import Tooltip from '@material-ui/core/Tooltip';
import Header from '../../Header';
import axios from 'axios';
import {BaseUrl} from '../../../API';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';


const StudentFees=()=>{








// const getStudentFees=()=>{


// axios.get(`${BaseUrl}/`)

// }



return(
    <>
    <Header/>
    <div className='studentfees_container'>
    <div className='fees_table' >
          <MaterialTable
            title="Fees Details"
            columns={[
              { title: 'Date', field: 'id' },
              { title: 'Amount', field: 'first_name' },
              { title: 'Receipt number', field: 'last_name' },
              
            ]}
            data={query =>
              new Promise((resolve, reject) => {
                let url = 'https://reqres.in/api/users?'
                url += 'per_page=' + query.pageSize
                url += '&page=' + (query.page + 1)
                fetch(url)
                  .then(response => response.json())
                  .then(result => {
                    resolve({
                      data: result.data,
                      page: result.page - 1,
                      totalCount: result.total,
                    })
                  })
              })
            }
            actions={[
              {
                icon: 'cloud_download',
                tooltip: 'Download file',
                onClick: (event, rowData) => alert("You saved " + rowData.name)
              },

            ]}
            options={{
              actionsColumnIndex: -1,
              search: false
            }}
          />
        </div>
    </div>
 
    </>
)

}

export default StudentFees;
























